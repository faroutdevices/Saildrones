using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Voyages : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            SqlConnection objConnection = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["Connection1"].ConnectionString);
            SqlCommand objCommand;
            SqlDataReader objDataReader;
            objConnection.Open();

            string strLocate_Vessel = "select LastFixTime, Latitude, Longitude, Course, SpeedinKnots from saildrones_1 where Latitude <> '' and id > 160 order by id desc";

            objCommand = new SqlCommand(strLocate_Vessel, objConnection);
            objDataReader = objCommand.ExecuteReader();

            if (objDataReader.HasRows)
            {
                gvVoyageHistory.DataSource = objDataReader;
                gvVoyageHistory.DataBind();
            }


//get photos
objDataReader.Close();
            string strGetPhotos = "select filename from saildrones_1_photos where id = 71 order by id desc";

            objCommand = new SqlCommand(strGetPhotos, objConnection);
            objDataReader = objCommand.ExecuteReader();

            if (objDataReader.HasRows)
            {
objDataReader.Read();
//lbPhoto.Text = "<img src=" + + ">ppppppppppppp";
imageVoyage1.ImageUrl =  "http://speakeasy.org/~cjsp/" + objDataReader["FileName"].ToString();

                //gvVoyagePhotos.DataSource = objDataReader;
                //gvVoyagePhotos.DataBind();
            }


        }
    }
    protected void btnRuddertoStarboard_Click(object sender, EventArgs e)
    {
        lbCurrentActionPending.Text = "Rudder to Starboard";
        SetButtonsInactive();
    }
    protected void btnRuddertoPort_Click(object sender, EventArgs e)
    {
        lbCurrentActionPending.Text = "Rudder to Port";
        SetButtonsInactive();
    }
    protected void btnLocateVessel_Click(object sender, EventArgs e)
    {
        lbCurrentActionPending.Text = "Helm Report";
        SetButtonsInactive();
    }
    protected void btnSailTrim_Click(object sender, EventArgs e)
    {
        lbCurrentActionPending.Text = "Sail Trim to " + tbSailTrim.Text;
        SetButtonsInactive();
    }
    protected void btnRequestVideo_Click(object sender, EventArgs e)
    {
        lbCurrentActionPending.Text = "Video Capture";
        SetButtonsInactive();
    }

    protected void SetButtonsInactive()
    {
        tbSailTrim.Enabled = false;
        btnSailTrim.Enabled = false;
        //btnLocateVessel.Enabled = false;
        btnRuddertoPort.Enabled = false;
        btnRuddertoStarboard.Enabled = false;
        btnSailTrim.Enabled = false;
        //Button1.Enabled = false;
        tbSailTrim.Enabled = false;
    }

    ////////////String ConnectionString = "Data Source=faroutdevices1.db.5649148.hostedresource.com;Initial Catalog=faroutdevices1;User ID=faroutdevices1;Password=Strong11111111;";


    //////////           SqlConnection objConnection = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["Connection1"].ConnectionString);
    //////////            SqlCommand objCommand;
    //////////            SqlDataReader objDataReader;
    //////////            objConnection.Open();

    ////////// /*

    //////////            string strVessels_List = "select * from saildrones_1 order by id desc";

    //////////            objCommand = new SqlCommand(strVessels_List, objConnection);

    //////////            objDataReader = objCommand.ExecuteReader();

    //////////            if (objDataReader.HasRows)
    //////////            {
    //////////                //objDataReader.Read();
    //////////                ddVessels.DataSource = objDataReader;
    //////////                ddVessels.DataTextField = "name";
    //////////                ddVessels.DataValueField = "imei";
    //////////                ddVessels.DataBind();

    //////////                ddVessels.SelectedIndex = 0;
    //////////              }


    //////////objDataReader.Close();
    //////////*/

    //////////            //string strLocate_Vessel = "select * from saildrones_1 where IMEI = @IMEI";
    //////////            string strLocate_Vessel = "select * from saildrones_1 order by id desc";

    //////////            objCommand = new SqlCommand(strLocate_Vessel, objConnection);
    //////////            //objCommand.Parameters.Add("@IMEI", SqlDbType.VarChar);
    //////////            //objCommand.Parameters["@IMEI"].Value = ddVessels.SelectedValue;
    //////////            //objConnection.Open();
    //////////            objDataReader = objCommand.ExecuteReader();

    //////////            if (objDataReader.HasRows)
    //////////            {
    //////////                objDataReader.Read();

    ////////////tbStatus.Text = objDataReader["Status"].ToString();
    //////////tbLastFixTime.Text = objDataReader["LastFixTime"].ToString();
    //////////tbLatitude.Text = objDataReader["Latitude"].ToString();
    //////////tbLongitude.Text = objDataReader["Longitude"].ToString();
    //////////tbCourse.Text = objDataReader["Course"].ToString();
    //////////tbSpeedInKnots.Text = objDataReader["SpeedInKnots"].ToString();
    //////////tbSatelitesInView.Text = objDataReader["SatelitesInView"].ToString();

    ////////////if (tbStatus.Text == "At Sea")
    ////////////{
    //////////btnLaunchVessel.Enabled = false;
    //////////btnLocateVessel.Enabled = true;
    //////////btnRuddertoStarboard.Enabled = true;
    //////////btnRuddertoPort.Enabled = true;
    //////////btnSailTrimOut.Enabled = true;
    //////////btnSailTrimIn.Enabled = true;

    ////////////}
    ////////////else
    ////////////{
    ////////////btnLaunchVessel.Enabled = true;
    ////////////btnLocateVessel.Enabled = false;
    ////////////btnRuddertoStarboard.Enabled = false;
    ////////////btnRuddertoPort.Enabled = false;
    ////////////btnSailTrimOut.Enabled = false;
    ////////////btnSailTrimIn.Enabled = false;
    ////////////}

    ////////////imageMap.ImageUrl = "http://maps.google.com/maps/api/staticmap?center=" + tbLatitude.Text + "," + tbLongitude.Text + "&zoom=12&size=800x800&maptype=satellite&sensor=false";

    //////////imageMap.ImageUrl = "http://maps.google.com/maps/api/staticmap?center=48.214728,-122.658672&zoom=12&size=800x800&maptype=satellite&sensor=false";

    //////////}





    //////////protected void btnTrackVessel_Click(object sender, EventArgs e)
    //////////{
    //////////SqlConnection objConnection = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["Connection1"].ConnectionString);
    //////////SqlCommand objCommand;
    //////////SqlDataReader objDataReader;
    //////////objConnection.Open();

    //////////string strLocate_Vessel = "select * from saildrones_1 order by id ASC";

    //////////objCommand = new SqlCommand(strLocate_Vessel, objConnection);
    //////////objDataReader = objCommand.ExecuteReader();

    //////////if (objDataReader.HasRows)
    //////////{
    //////////    objDataReader.Read();

    //////////    lbLastFixTime.Text = "dfd"; // objDataReader["LastFixTime"].ToString();
    //////////    lbLatitude.Text = objDataReader["Latitude"].ToString();
    //////////    lbLongitude.Text = objDataReader["Longitude"].ToString();
    //////////    lbCourse.Text = objDataReader["Course"].ToString();
    //////////    lbSpeedInKnots.Text = objDataReader["SpeedInKnots"].ToString();
    //////////    lbSatelitesInView.Text = objDataReader["SatelitesInView"].ToString();


    //////////    btnLaunchVessel.Enabled = false;
    //////////    btnLocateVessel.Enabled = true;
    //////////    btnRuddertoStarboard.Enabled = true;
    //////////    btnRuddertoPort.Enabled = true;
    //////////    btnSailTrimOut.Enabled = true;
    //////////    btnSailTrimIn.Enabled = true;

    //////////    //imageMap.ImageUrl = "http://maps.google.com/maps/api/staticmap?center=48.214728,-122.658672&zoom=12&size=800x800&maptype=satellite&sensor=false";

    //////////}
    //////////}


    //////    protected void ddVessels_SelectedIndexChanged(object sender, EventArgs e)
    //////    {

    //////String ConnectionString = "Data Source=faroutdevices1.db.5649148.hostedresource.com;Initial Catalog=faroutdevices1;User ID=faroutdevices1;Password=Strong11111111;";

    //////            SqlConnection objConnection = new SqlConnection(ConnectionString);
    //////            SqlCommand objCommand;
    //////            SqlDataReader objDataReader;

    //////            string strLocate_Vessel = "select * from saildrones_1 where IMEI = @IMEI";

    //////            objCommand = new SqlCommand(strLocate_Vessel, objConnection);
    //////            objCommand.Parameters.Add("@IMEI", SqlDbType.VarChar);
    //////            objCommand.Parameters["@IMEI"].Value = ddVessels.SelectedValue;
    //////            objConnection.Open();
    //////            objDataReader = objCommand.ExecuteReader();

    //////            if (objDataReader.HasRows)
    //////            {
    //////                objDataReader.Read();

    ////////lbStatus.Text = objDataReader["Status"].ToString();
    //////lbLastFixTime.Text = objDataReader["LastFixTime"].ToString();
    //////lbLatitude.Text = objDataReader["Latitude"].ToString();
    ////////lbLongitude.Text = objDataReader["Longitude"].ToString();
    ////////lbCourse.Text = objDataReader["Course"].ToString();
    ////////lbSpeedInKnots.Text = objDataReader["SpeedInKnots"].ToString();
    ////////lbSatelitesInView.Text = objDataReader["SatelitesInView"].ToString();


    ////////if (lbStatus.Text == "At Sea")
    ////////{
    ////////btnLaunchVessel.Enabled = false;
    ////////btnLocateVessel.Enabled = true;
    ////////btnRuddertoStarboard.Enabled = true;
    ////////btnRuddertoPort.Enabled = true;
    ////////btnSailTrimOut.Enabled = true;
    ////////btnSailTrimIn.Enabled = true;

    ////////}
    ////////else
    ////////{
    //////btnLaunchVessel.Enabled = true;
    //////btnLocateVessel.Enabled = false;
    //////btnRuddertoStarboard.Enabled = false;
    //////btnRuddertoPort.Enabled = false;
    ////////btnSailTrimOut.Enabled = false;
    ////////btnSailTrimIn.Enabled = false;
    ////////}


    //////imageMap.ImageUrl = "http://maps.google.com/maps/api/staticmap?center=48.214728,-122.658672&zoom=12&size=800x800&maptype=satellite&sensor=false";

    //////}

    //////    }




    //SqlConnection objConnection = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["Connection1"].ConnectionString);
    //SqlCommand objCommand;
    //SqlDataReader objDataReader;
    //objConnection.Open();

    //string strLocate_Vessel = "select * from saildrones_1 order by id Desc";

    //objCommand = new SqlCommand(strLocate_Vessel, objConnection);
    //objDataReader = objCommand.ExecuteReader();

    //if (objDataReader.HasRows)
    //{
    //    objDataReader.Read();

    //    lbLastFixTime.Text = objDataReader["LastFixTime"].ToString();
    //    lbLatitude.Text = objDataReader["Latitude"].ToString();
    //    lbLongitude.Text = objDataReader["Longitude"].ToString();
    //    lbCourse.Text = objDataReader["Course"].ToString();
    //    lbSpeedInKnots.Text = objDataReader["SpeedInKnots"].ToString();
    //    lbSatelitesInView.Text = objDataReader["SatelitesInView"].ToString();


    //    btnLaunchVessel.Enabled = false;
    //    btnLocateVessel.Enabled = true;
    //    btnRuddertoStarboard.Enabled = true;
    //    btnRuddertoPort.Enabled = true;
    //    //btnSailTrimOut.Enabled = true;
    //    //btnSailTrimIn.Enabled = true;

    //    //imageMap.ImageUrl = "http://maps.google.com/maps/api/staticmap?center=48.214728,-122.658672&zoom=12&size=800x800&maptype=satellite&sensor=false";

    //}





}
