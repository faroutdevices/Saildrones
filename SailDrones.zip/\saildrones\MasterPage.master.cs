using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        //if (Session["login"] != "Logged_In")
        //{
        //    Response.Redirect("login.aspx");
        //}

        Uri uri = Request.Url;
        string[] segment = uri.Segments;
        string page = string.Empty;
        if( 0 < segment.Length )
        {
            page = segment[segment.Length - 1];
        }

        hlDefault.CssClass = "tabNavigation_navitem";
        hlVoyages.CssClass = "tabNavigation_navitem";
        hlCharters.CssClass = "tabNavigation_navitem";
        hlSos.CssClass = "tabNavigation_navitem";
        hlAboutUs.CssClass = "tabNavigation_navitem";

        page = page.ToLower();

        if (page == "default.aspx") { hlDefault.CssClass = "active"; }
        if (page == "voyages.aspx") { hlVoyages.CssClass = "active"; }
        if (page == "charters.aspx") { hlCharters.CssClass = "active"; }
        if (page == "sos.aspx") { hlSos.CssClass = "active"; }
        if (page == "aboutus.aspx") { hlAboutUs.CssClass = "active"; }
    }
}
